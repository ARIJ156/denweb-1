DEPLOY (JANGAN ubah Worker denweb22: itu tempat website Anda)

1. Buat Worker BARU khusus API jadwal
   Cloudflare > Workers & Pages > Create > Create Worker
   Nama: denalize-jadwal  > Deploy > Edit code
   Hapus semua kode, tempel isi cloudflare-worker/worker.js > Deploy
2. Settings > Variables and secrets (Production) di Worker denalize-jadwal:
     Secret JKT48CONNECT_API_KEY = key jkc_...
     Text   ALLOWED_ORIGINS      = https://denanatalia.my.id,https://www.denanatalia.my.id
   Deploy ulang.
3. Tes: buka https://denalize-jadwal.arjunramadhan31.workers.dev/?debug=1  (harus muncul JSON success:true)
   Jika subdomain akun Anda bukan arjunramadhan31, ubah JKT48_THEATER_URL di bagian atas schedule-v12.js.
4. Upload index.html dan schedule-v12.js ke website, lalu Ctrl+Shift+R.

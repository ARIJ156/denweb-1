// KONFIGURASI JADWAL THEATER JKT48 - DENALIZE
// URL ini adalah alamat Worker Cloudflare, bukan alamat API JKT48Connect.
// API key hanya disimpan sebagai Secret di Cloudflare Worker.
export const JKT48_THEATER_URL =
  "https://denweb22.arjunramadhan31.workers.dev";

// Cache sisi browser (menit). Worker melakukan cache edge selama 60 detik.
export const CACHE_MINUTES = 180;
